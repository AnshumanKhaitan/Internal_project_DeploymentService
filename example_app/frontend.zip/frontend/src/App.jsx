import React, { useState, useEffect } from 'react';

export default function App() {
  const [backendMessage, setBackendMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [clickedTimes, setClickedTimes] = useState(0);

  // Retrieve base API URL from environment variable injected by Anti Gravity
  const apiBaseUrl = import.meta.env.VITE_API_URL || 'http://localhost:8000';

  const handleButtonClick = () => {
    const nextCount = clickedTimes + 1;
    setClickedTimes(nextCount);
    
    // Core user requirement: Console.log on button click
    console.log(`Button clicked! Total clicks: ${nextCount}. API Base URL: ${apiBaseUrl}`);
  };

  const fetchBackendData = async () => {
    setLoading(true);
    try {
      console.log(`Fetching from backend: ${apiBaseUrl}/api/message`);
      const response = await fetch(`${apiBaseUrl}/api/message`);
      const data = await response.json();
      setBackendMessage(data.message || JSON.stringify(data));
      console.log('Backend response fetched successfully:', data);
    } catch (error) {
      console.error('Error fetching backend data:', error);
      setBackendMessage(`Error connecting to backend at ${apiBaseUrl}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div className="icon">🚀</div>
      <h1>Anti Gravity Demo App</h1>
      <p className="subtitle">Fully-deployed Next-Gen Microservice Architecture</p>
      
      <div className="button-group">
        <button onClick={handleButtonClick}>
          Click Me (Trigger Console.log)
        </button>
        
        <button 
          onClick={fetchBackendData} 
          style={{ background: 'transparent', border: '1px solid rgba(255, 255, 255, 0.15)', boxShadow: 'none' }}
        >
          {loading ? 'Fetching...' : 'Fetch Backend Data'}
        </button>
      </div>

      <div className="status-box">
        <p>Console Log Action</p>
        <div className="content" style={{ color: clickedTimes > 0 ? '#38bdf8' : 'inherit' }}>
          {clickedTimes > 0 
            ? `Logged to console ${clickedTimes} time(s)!` 
            : 'Click the button above to log message to console.'}
        </div>
      </div>

      <div className="status-box">
        <p>Backend Response (API URL: {apiBaseUrl})</p>
        <div className={`content ${!backendMessage ? 'empty' : ''}`}>
          {backendMessage || 'No backend message fetched yet. Click "Fetch Backend Data".'}
        </div>
      </div>
    </div>
  );
}
