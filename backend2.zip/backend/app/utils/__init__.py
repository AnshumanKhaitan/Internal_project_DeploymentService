# Utility functions module
